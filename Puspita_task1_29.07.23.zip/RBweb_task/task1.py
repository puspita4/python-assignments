#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Write a Python program that takes an integer as input and counts the number of odd and even digits in it.The program should 
# print the count of odd and even digits separately.

number = int(input("Enter a number: "))
if number % 2 == 0:
    print("{0} is even number". format(number))
else:
    print("{0} is even number". format(number))


# In[3]:


# Vowel or Consonant Checker: Write a Python program that takes a character as input and checks if it is a vowel or a consonant. The program should print "Vowel" 
#if the character is a vowel (a, e, i, o, u - both uppercase and lowercase), and "Consonant" otherwise.

cha = input("Enter the Alphabet: ")
if cha in ('a','e','i','o','u','A','E','I','O','U'):
    print(cha,"is a vowel")
else:
    print(cha,"is a consonant")


# In[9]:


# Write a Python program that takes the original price of a product and the discount percentage as input. The program should calculate 
#the discounted price and print it. If the discount percentage is invalid (less than 0 or greater than 100), the program should print "Invalid discount 
#percentage."

amount = int(input("Enter original price of a product: "))
if(amount>0):
    if amount <= 10000:
        dis = amount * 0.25
    elif amount <= 5000:
        dis = amount * 0.15
    elif amount <= 2000:
        dis = amount * 0.07
    else:
        dis = amount * 0.3
        print("discount: ", dis)
        print("Net pay: ", amount-dis)
else:
    print("Invalid input")


# In[16]:


# Temperature Converter: Write a Python program that takes a temperature value and the temperature scale (Celsius or Fahrenheit) as 
#input. The program should convert the temperature to the other scale and print the result.

celsius = float(input("Enter a celsius value: "))
fahrenheit = (celsius * 1.8) + 32
print("Temperature in fahrenheit is", fahrenheit)


# In[15]:


fahrenheit = float(input("Enter a fahrenheit value: "))
celsius = (fahrenheit - 32) * 5/9
print("Temperature in celcius is", celsius)


# In[ ]:





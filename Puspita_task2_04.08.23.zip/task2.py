#!/usr/bin/env python
# coding: utf-8

# In[35]:


# Write a Python program to print all even numbers between 1 and 20 using a lfor loop.

for even_numbers in range(1,20,2):
    print(even_numbers)


# In[34]:


# Write a Python program to find the sum of all odd numbers between 1 and 50 using a while loop.
n = 50
sum = 0
i = 1
while (i<=n):
    sum = sum + i
    i = i + 2
    print(sum)


# In[33]:


# Given a list of numbers, write a Python program to find and print the maximum number using a for loop and if-else statement.

list1 = []
 
num = int(input("Enter number of elements in list: "))

for i in range(1, num + 1):
    ele = int(input("Enter elements: "))
    list1.append(ele)
    print("Largest element is:", max(list1))


# In[28]:


# Write a Python program to check if a given number is prime using a for loop and an if-else statement.

n = 7
if n > 1:
    for i in range(2, int(n/2)):
        if (n % i) == 0:
            print(n, "is not a prime number")
            break
        else:
            print(n, "is a prime number")


# In[28]:


# Write a Python program to calculate the factorial of a given number using a while loop.

num = int(input("enter a number: "))
 
fac = 1
i = 1
 
while i <= num:
    fac = fac * i
    i = i + 1
    print("factorial of ", num, " is ", fac)


# In[31]:


# Given a list of strings, write a Python program to find the longest string using a for loop and if-else statement.

str = input("Enter a String:")
words = str.split()
longest_word = words[0] 
max_len = len(words[0])
for index, word in enumerate(words):
    if len(word)> max_len:
        max_len = len(word)
        longest_word = word
    else:
        pass
idx = str.find(longest_word)
print("Longest word: ",longest_word)


# In[32]:


# Write a Python program to print the Fibonacci series up to n terms using a while loop.

n = int(input("Enter a number: "))
a = 0
b = 1
sum = a + b
count = 1
print("Fibonacci series is: ", end=" ")
while (count <= n):
    count += 1
    print(a, end=" ")
    a = b
    b = sum
    sum = a + b


# In[4]:


# Write a Python program to check if a given string is a palindrome using a for loop and an if else statement.

string = input("Enter a string : ")
revstr = "" 
for i in string:
    revstr = i + revstr
print("Reversed string : ", revstr) 
 
if(string==revstr): 
     print("The string is a palindrome.") 
else: 
    print("The string is not a palindrome.")


# In[16]:


# Given a list of integers, write a Python program to calculate the sum of positive and negative numbers separately using a for loop and if-else statements.

list1 = [10, -25, 6, -78, 66, -93, 1]
 
pos_count = 0 
neg_count = 0
 
for num in list1:
 
    if num >= 0:
        pos_count += 1
        print("Positive numbers in the list: ", pos_count)
 
    else:
        neg_count += 1
        print("Negative numbers in the list: ", neg_count)


# In[21]:


# Write a Python program to print the multiplication table of a given number using a for loop.

num = int(input("Enter a number: "))
for i in range(1, 11):
       print(num,"X",i,"=",num * i)


# In[13]:


# Given a n no of numbers, write a Python program to count how many are even and how many are odd using a for loop and if-else statements.

n = (9,2,7,90,67,45,7,12)
even_count = 0
odd_count = 0
for i in n:
    if i % 2 == 0:
        even_count += 1
        print("Even numbers in the list: ", even_count)
 
    else:
        odd_count += 1
        print("Odd numbers in the list: ", odd_count)


# In[ ]:


# Write a Python program to simulate a simple dice game using a while loop and an if-else statement.


# In[17]:


# Write a Python program to check if a given number is a perfect square using a for loop and an if-else statement.

num = int(input("Enter a number: "))
result = 0
for i in range(1,num):
    if num % i == 0:
        result = result + i
        if result == num:
            print("it is a perfect number")
        else:
            print("It's not a perfect number")


# In[26]:


# Given a list of strings, write a Python program to count the number of vowels and consonants using a for loop and if-else statements.

num = input("Enter a string: ")
vowels = 0
consonants = 0
for i in num:
    if(i == 'a' or i == 'e' or i == 'i' or i == 'o' or i == 'u'or i == 'A' or i == 'E' or i == 'I' or i == 'O' or i == 'U'):
        vowels = vowels + 1
        print("Total Number of Vowels in this String = ", vowels)
    else:
        consonants = consonants + 1
        print("Total Number of consonants in this String = ", consonants)


# In[34]:


# Write a Python program to find the factorial of a given number using both iterative approaches. Use a for loop in the iterative version.

num = int(input("Enter a number: "))
fact = 1
if num < 0:
    print("factorial does not exist for negative numbers")
elif num == 0:
    print("The factorial of 0 is 1")
else:
    for i in range(1,num + 1):
        fact = fact*i
    print("The factorial of",num,"is",fact)


# In[40]:


# Write a Python program to generate the first n prime numbers using a while loop and a for loop.
# using for loop
n = int(input("Enter a number: "))
for n in range (1, n + 1):
    if n > 1:  
        for i in range (2, n):
            if (n % i) == 0:
                break  
        else:  
            print (n)  


# In[48]:


# Given a list of integers, write a Python program to find and print the second-largest number using a for loop and if-else statement.

a=[]
n=int(input("Enter number of elements: "))
for i in range(1,n+1):
    b=int(input("Enter element: "))
    a.append(b)
a.sort()
print("Second largest element is: ",a[n-2])


# In[49]:


# Write a Python program that takes a year as input and checks if it's a leap year using an if else statement.

year = int(input("Enter a year:"))
if (year % 400 == 0) and (year % 100 == 0):
    print("{0} is a leap year".format(year))

elif (year % 4 ==0) and (year % 100 != 0):
    print("{0} is a leap year".format(year))

else:
    print("{0} is not a leap year".format(year))


# In[52]:


# Write a Python program to reverse a given string using both a for loop and a while loop.

string = "I am puspita giri"
reversed = '' 
for i in string:
    reversed = i + reversed  
print(reversed)


# In[8]:


# while loop
string = "I am puspita giri"
i = string
reverse = ''
while(len(i) > 0):
    if(len(i) > 0):
        a = i[-1]
        i = i[:-1]
        reverse += a
print('The reverse string is', reverse)


# In[9]:


# Write a Python program to find and print all the Armstrong numbers between 1 and 1000. 
#Armstrong numbers are numbers that are equal to the sum of their digits raised to the 
#power of the number of digits they have. For example, 153 is an Armstrong number since 
#1^3 + 5^3 + 3^3 = 153

lower = 1
upper = 1000

for num in range(lower, upper + 1):
    order = len(str(num))
    sum = 0
    temp = num
    while temp > 0:
        digit = temp % 10
        sum += digit ** order
        temp //= 10
    if num == sum:
        print(num)

